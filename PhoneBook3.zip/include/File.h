#ifndef FILE_H
#define FILE_H


class File
{
    public:
        File();

    protected:

    private:
};

#endif // FILE_H
