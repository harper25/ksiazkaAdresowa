#ifndef CONVERSION_H
#define CONVERSION_H

#include <string>

class Conversion
{
    public:
        Conversion();
        int string2int(std::string);

    protected:

    private:
};

#endif // CONVERSION_H
